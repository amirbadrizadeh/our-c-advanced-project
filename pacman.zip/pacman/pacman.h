#ifndef PACMAN_H
#define PACMAN_H
#include "moving.h"

class pacman:public moving
{
public:
    pacman();

private:
    int life;
};

#endif // PACMAN_H
