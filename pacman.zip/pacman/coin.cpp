#include "coin.h"

coin::coin()
{
    myscore = 50;
}
