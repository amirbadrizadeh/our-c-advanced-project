#include "mainwindow.h"
#include "mainobject.h"
#include <QGraphicsView>
#include <QGraphicsScene>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    mainObject o;

}

MainWindow::~MainWindow()
{
    
}
