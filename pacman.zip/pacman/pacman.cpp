#include "pacman.h"

pacman::pacman()
{
    life = 3;
}
