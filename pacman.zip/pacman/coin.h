#ifndef COIN_H
#define COIN_H
#include "eat_able.h"

class coin:public eat_able
{
public:
    coin();

private:
    int myscore;
};

#endif // COIN_H
