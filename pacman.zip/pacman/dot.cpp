#include "dot.h"

dot::dot()
{
    myscore = 10;
}
