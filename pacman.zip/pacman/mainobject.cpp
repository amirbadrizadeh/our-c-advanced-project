#include "mainobject.h"

mainObject::mainObject()
{
    QFile mapFile(":/resourses/file/map.map");

    if (!mapFile.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            // TODO: implement notifying the user of missing data.
            qDebug("Error: map file not found.");
            return;
        }

    QTextStream textStream(&mapFile);

    // Read the data until the end of file, omitting ASCII control characters.
    char current;
    for(int i=0 ; i<31 ; ++i)
        for(int j = 0 ; j<28 ; ++j){
            textStream >> current;
            map[i][j] = current;
        }
    mapFile.close();

    /*QFile file(":/resourses/file/file.txt");
    if (!file.open(QIODevice::ReadWrite | QIODevice::Text))
        {
            // TODO: implement notifying the user of missing data.
            qDebug("Error: map file not found.");
            return;
        }
    QTextStream str(&file);
    for(int i=0 ; i<31 ; ++i)
        for(int j = 0 ; j<28 ; ++j){
            str << map[i][j];
        }
    file.close();*/


}
