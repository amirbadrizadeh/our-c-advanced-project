#ifndef ENEMY_RED_H
#define ENEMY_RED_H
#include "enemy.h"

class enemy_red:public enemy
{
public:
    enemy_red();
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
private:
    QPixmap *image[2];
};

#endif // ENEMY_RED_H
