#include "enemy_pick.h"

enemy_pick::enemy_pick()
{
    image[0]=new QPixmap(":/img/resourses/image/pink.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");
}
QRectF enemy_pick::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
enemy_pick::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(0,0,image[0]->width(),image[0]->height(),(*image[0]));
}
