#include "sour_cherry.h"

sour_cherry::sour_cherry()
{
    myscore = 100;
}
