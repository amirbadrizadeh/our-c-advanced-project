#ifndef MOVING_H
#define MOVING_H
#include "mainobject.h"

class moving:public mainObject
{
public:
    moving();
};

#endif // MOVING_H
