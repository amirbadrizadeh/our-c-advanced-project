#include "enemy_red.h"

enemy_red::enemy_red()
{
    image[0]=new QPixmap (":/img/resourses/image/red.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");
}
QRectF enemy_red::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_red::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(0,0,image[0]->width(),image[0]->height(),(*image[0]));
}
