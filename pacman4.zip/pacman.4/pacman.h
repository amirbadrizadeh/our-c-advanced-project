#ifndef PACMAN_H
#define PACMAN_H
#include "moving.h"
#include <QPixmap>
#include <QPainterPath>
#include <QKeyEvent>
#include <QTimer>
#include <QObject>

class pacman:public moving,public QObject
{
    //Q_OBJECT
public:
    pacman();
    ~pacman();


    QRectF boundingRect()const Q_DECL_OVERRIDE;
    QPainterPath shape() const Q_DECL_OVERRIDE;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*)Q_DECL_OVERRIDE;

public slots:
    void move();

protected:
    void advance(int)Q_DECL_OVERRIDE;
    void keyPressEvent(QKeyEvent *event)Q_DECL_OVERRIDE;

private:

    int life;
    QPixmap *image[6];
    int what_showing;
    QTimer *timer;
    int pre;
};

#endif // PACMAN_H
