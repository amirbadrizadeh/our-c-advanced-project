#ifndef ENEMY_BLUE_H
#define ENEMY_BLUE_H
#include "enemy.h"

class enemy_blue:public enemy
{
public:
    enemy_blue();
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    QPixmap *image[2];
};

#endif // ENEMY_BLUE_H
