#ifndef ENEMY_ORANGE_H
#define ENEMY_ORANGE_H
#include "enemy.h"

class enemy_orange:public enemy
{
public:
    enemy_orange();
     QRectF boundingRect()const;
     void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
private:
         QPixmap *image[2];
};

#endif // ENEMY_ORANGE_H
