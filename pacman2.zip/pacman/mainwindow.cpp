#include "mainwindow.h"
#include "mainobject.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setFixedSize(600,600);

    view = new QGraphicsView(this);
    view->setFixedSize(600,600);

    scene = new QGraphicsScene(0,0,600-2,600-2,view);
    view->setScene(scene);

    pac = new pacman;
    pac->setScale(0.5);
    scene->addItem(pac);



}

MainWindow::~MainWindow()
{
    
}
