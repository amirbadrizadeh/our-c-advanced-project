#ifndef MAINOBJECT_H
#define MAINOBJECT_H
#include <QGraphicsItem>
#include <QPainter>
#include <QString>
#include <QChar>
#include <QFile>
#include <QTextStream>

class mainObject:public QGraphicsItem
{
public:
    mainObject();



protected:
    char map[31][28];
};

#endif // MAINOBJECT_H
