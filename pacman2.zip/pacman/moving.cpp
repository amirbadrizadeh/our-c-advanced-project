#include "moving.h"

moving::moving()
{
}
