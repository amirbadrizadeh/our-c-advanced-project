#ifndef WALL_H
#define WALL_H
#include "mainobject.h"

class wall:public mainObject
{
public:
    wall();
};

#endif // WALL_H
