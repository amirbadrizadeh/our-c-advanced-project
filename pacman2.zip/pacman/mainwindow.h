#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include "pacman.h"
#include "dot.h"
#include <QGraphicsView>
#include <QGraphicsScene>

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    QGraphicsView *view;
    QGraphicsScene *scene;
    pacman *pac;


};

#endif // MAINWINDOW_H
