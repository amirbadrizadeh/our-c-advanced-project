#include "mainwindow.h"
#include "mainobject.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    int width=650,height=700;
    setWindowTitle("Pac Man");
    setFixedSize(width,height);



    view = new QGraphicsView(this);
    view->setFixedSize(width,height);

    scene = new QGraphicsScene(0,0,width-2,height-2);
    view->setScene(scene);
    //scene->setBackgroundBrush(Qt::black);

    // Add wall
    for(int i=0; i<wall::num; ++i){
        walls[i] = new wall();
        walls[i]->setScale(0.2);
        scene->addItem(walls[i]);
    }

    // Add dot
    for(int i=0; i<dot::num; ++i){
        dots[i] = new dot();
        dots[i]->setScale(20/500.0);
        scene->addItem(dots[i]);
    }

    // Add coin
    for(int i=0; i<coin::num; ++i){
        coins[i] = new coin();
        coins[i]->setScale(20/205.0);
        scene->addItem(coins[i]);
    }

    // Add pacman
    pac = new pacman;
    pac->setFlag(QGraphicsItem::ItemIsFocusable);
    pac->setFocus();
    scene->addItem(pac);

    // Add enemy

    //orange enemy
    orange=new enemy_orange;
    orange->setScale(20/320.0);
    scene->addItem(orange);
    //pink enemy
    pick=new enemy_pick;
    pick->setScale(20/320.0);
    scene->addItem(pick);
    //red enemy
    red=new enemy_red;
    red->setScale(20/320.0);
    //scene->addItem(red);
    //blue enemy




    // Add progress

    timer = new QTimer;
    connect(timer,SIGNAL(timeout()),scene,SLOT(advance()));
    timer->start(100);

}

MainWindow::~MainWindow()
{
    delete view;
    delete scene;
    delete timer;
    //delete pac;
}
