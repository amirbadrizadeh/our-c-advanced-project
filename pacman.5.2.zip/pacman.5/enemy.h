#ifndef ENEMY_H
#define ENEMY_H
#include "moving.h"
#include <QPixmap>

class enemy:public moving
{
public:
    enemy();

    void setMode(){}

    //virtual void advance(int);

protected:
    void moveRandom();

private:
    bool mode;
    bool state;
    int dx,dy;
    int side;

};


#endif // ENEMY_H
