#include "enemy_pick.h"
#include <QList>
#include <QGraphicsScene>
#include "pacman.h"
#define DDD 2.5

enemy_pick::enemy_pick()
{
    image[0]=new QPixmap(":/img/resourses/image/pink.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");
    setPos(20,20);
    is_static=true;
}
QRectF enemy_pick::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_pick::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[0]->width(),image[0]->height(),(*image[0]));
}
void enemy_pick::advance(int)
{
    QList<QGraphicsItem*> list_pacman=scene()->items();
    int i,n;
    for(i=0,n=list_pacman.size(); i<n; ++i){
        if(typeid(*(list_pacman[i]))==typeid(pacman)){

            break;
        }
    }

    /*if(x()<=list_pacman[i]->x()+55 && y()<=list_pacman[i]->y()+55){
        if(goRight(x(),y(),0,0)){
            setPos(x()+DDD,y());
            is_static=false;
        }
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DDD);
            is_static=false;
        }

        enemy::advance(1);
    }*/

    /*else if(x()<=list_pacman[i]->x()+55 && y()>=list_pacman[i]->y()+55){
        if(goRight(x(),y(),0,0)){
            setPos(x()+DDD,y());
            is_static=false;
        }
        if(goUp(x(),y(),0,5)){
            setPos(x(),y()-DDD);
            is_static=false;
        }
        enemy::advance(1);
    }*/

    /*else if(x()>=list_pacman[i]->x()+55 && y()<=list_pacman[i]->y()+55){
        if(goLeft(x(),y(),0,5)){
            setPos(x()-DDD,y());
            is_static=false;
        }
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DDD);
            is_static=false;
        }
        enemy::advance(1);
    }*/

    /*else if(x()>=list_pacman[i]->x()+55 && y()>=list_pacman[i]->y()+55){
        if(goLeft(x(),y(),0,5)){
            setPos(x()-DDD,y());
            is_static=false;
        }
        if(goUp(x(),y(),0,5)){
            setPos(x(),y()-DDD);
            is_static=false;
        }
        enemy::advance(1);
    }*/


    enemy::moveRandom();

    is_static=true;
}
