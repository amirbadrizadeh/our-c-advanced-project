#include "enemy.h"
#define DD 5

enemy::enemy()
{
    mode = true;//oridinary
    side=0;
}
void enemy::moveRandom()
{
    switch(side){
    case 0://Right
        if(goRight(x(),y(),0,0)){
            setPos(x()+DD, y());
            mode = false;
        }
        else
            mode=true;
        if(mode)
            side=qrand()%4;
        break;

    case 1://Down
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DD);
            mode=false;
        }
        else
            mode = true;
        if(mode)
            side=qrand()%4;
        break;

    case 2://Left
        if(goLeft(x(),y(),0,DD)){
            setPos(x()-DD,y());
            mode = false;
        }
        else
            mode = true;

        if(mode)
            side=qrand()%4;
        break;

    case 3://Up
        if(goUp(x(),y(),0,DD)){
            setPos(x(),y()-DD);
            mode = false;
        }
        else
            mode = true;
        if(mode)
             side=qrand()%4;
        break;
    }
}

/*void enemy::advance(int){
    switch(side){
    case 0://Right
        if(goRight(x(),y(),0,0)){
            setPos(x()+DD, y());
            mode = false;
        }
        else
            mode=true;
        if(mode)
            side=qrand()%4;
        break;

    case 1://Down
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DD);
            mode=false;
        }
        else
            mode = true;
        if(mode)
            side=qrand()%4;
        break;

    case 2://Left
        if(goLeft(x(),y(),0,DD)){
            setPos(x()-DD,y());
            mode = false;
        }
        else
            mode = true;

        if(mode)
            side=qrand()%4;
        break;

    case 3://Up
        if(goUp(x(),y(),0,DD)){
            setPos(x(),y()-DD);
            mode = false;
        }
        else
            mode = true;
        if(mode)
             side=qrand()%4;
        break;
    }

}*/
