#ifndef ENEMY_H
#define ENEMY_H
#include "moving.h"

class enemy:public moving
{
public:
    enemy();

private:
    bool mode;
};

#endif // ENEMY_H
