#include "pacman.h"
#include <math.h>
#include <QTransform>
#define DISTANCE 5

pacman::pacman()
{
    life = 3;
    image[0] = new QPixmap(":/img/resourses/image/0.png");
    image[1] = new QPixmap(":/img/resourses/image/1.png");
    image[2] = new QPixmap(":/img/resourses/image/2.png");
    image[3] = new QPixmap(":/img/resourses/image/3.png");
    image[4] = new QPixmap(":/img/resourses/image/4.png");
    image[5] = new QPixmap(":/img/resourses/image/5.png");


    what_showing = 0;


    //setScale(20/130.0);
    setScale(2);

    //setTransformOriginPoint(65,65);
    setTransformOriginPoint(image[what_showing]->height()/2, image[what_showing]->height()/2);

    setPos(13*20-65+10,23*20-65+10);
    //setPos(0,0);

}
QRectF pacman::boundingRect()const
{
    int adjust=1;
    return QRectF(0-adjust, 0-adjust, image[what_showing]->width()+adjust
                  , image[what_showing]->height()+adjust);
}
QPainterPath pacman::shape()const
{
    QPainterPath path;
    path.addRect(0,0,image[what_showing]->width(),image[what_showing]->height());
    return path;
}
void pacman::paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    //painter->drawPixmap(0,0,image[what_showing]->width(),image[what_showing]->height(),(*image[what_showing]));
    painter->drawText(0,0,20,20,Qt::AlignCenter,QString::number(x()));
}

void pacman::advance(int step)
{
    if(!step)
        return;

}

void pacman::keyPressEvent(QKeyEvent *event)
{
    if((++what_showing)==6)
        what_showing = 0;
    switch(event->key()){
    case Qt::Key_Right:
        if(map[(int)y()/20][(int)((x()+20)/20)] == 'W' )// || ::floor(y()/20)!=y()/20)
            return;
        else if(::floor(y()/20)!=y()/20 && map[(int)((y()+20)/20)][(int)((x()+20)/20)] == 'W')
            return;
        else
            setPos(x()+DISTANCE, y());
        setRotation(0);
        break;

    case Qt::Key_Left:
        setPos(x()-DISTANCE, y());
        setRotation(180);
        break;

    case Qt::Key_Up:
        setPos(x(), y()-DISTANCE);
        setRotation(270);
        break;

    case Qt::Key_Down:
        setPos(x(), y()+DISTANCE);
        setRotation(90);
        break;

    default:
        QGraphicsItem::keyPressEvent(event);
    }
}

pacman::~pacman()
{
    for(int i = 0; i<6; ++i)
        delete image[i];
}
