#ifndef MAINOBJECT_H
#define MAINOBJECT_H
#include <QGraphicsItem>
#include <QPainter>
#include <QString>
#include <QFile>
#include <QTextStream>

class mainObject:public QGraphicsItem
{
public:
    mainObject();

    // for test map
    /*QRectF boundingRect()const
    {
        return QRectF(-1,-1,601,651);
    }
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
    {
        QString s;
        for(int i = 0; i<31; ++i){
            for(int j = 0; j<28; ++j){
                s.append(map[i][j]);
            }
            s.append('\n');
        }
        painter->drawText(0,0,598,648,Qt::AlignCenter,s);
    }*/

protected:
    char map[31][28];
};

#endif // MAINOBJECT_H
