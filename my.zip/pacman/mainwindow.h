#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QTimer>
#include "pacman.h"
#include "coin.h"
#include "progress.h"
#include "wall.h"
#include "dot.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    //void keyPressEvent(QKeyEvent *);
    //void keyReleaseEvent(QKeyEvent *);

private:
    QGraphicsView *view;
    QGraphicsScene *scene;
    QTimer *timer;

    pacman *pac;

    wall *walls[wall::num];

};

#endif // MAINWINDOW_H
