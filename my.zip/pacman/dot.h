#ifndef DOT_H
#define DOT_H
#include "eat_able.h"

class dot:public eat_able
{
public:
    dot();

private:
    int myscore;
};

#endif // DOT_H
