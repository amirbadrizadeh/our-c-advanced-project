#include "eat_able.h"

eat_able::eat_able()
{
}
