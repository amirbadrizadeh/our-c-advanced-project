#ifndef WALL_H
#define WALL_H
#include "mainobject.h"
#include <QPixmap>

class wall:public mainObject
{
public:
    static int const num=478;
private:
    static int located;

public:
    wall();
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*);

private:
    QPixmap *image;
};

#endif // WALL_H
