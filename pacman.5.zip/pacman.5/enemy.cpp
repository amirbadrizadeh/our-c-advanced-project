#include "enemy.h"
#define DD 5

enemy::enemy()
{
    mode = true;//oridinary
    side=0;
}
void enemy::advance(int){
    switch(side){
    case 0://Right

    /*if( map[(int)(y()/20)][(int)((x()/20)+1)]!='W'){
        dx=DD;dy=0;
        setPos(x()+dx,y()+dy);
        mode=false;
    }
    else
    {
        mode=true;
    }*/
        if(goRight(x(),y(),0)){
            setPos(x()+DD, y());
            mode = false;
        }
        else
            mode=true;
    if(mode)
        side=qrand()%4;
    break;

    case 1://Down
    /*if(map[(int)(y()/20)+1][(int)(x()/20)]!='W')
    {
        dx=0;dy=DD;
        setPos(x()+dx,y()+dy);
    //    down=true;
         mode=false;
      //  i=1;
        //j=0;
    }
    else
    {
        mode=true;
    }*/
        if(goDown(x(),y(),0)){
            setPos(x(),y()+DD);
            mode=false;
        }
        else
            mode = true;
    if(mode)
        side=qrand()%4;
    break;

    case 2://Left
    /*if(map[(int)(y()/20)][(int)(x()/20)-1]!='W')
    {
        dx=-DD;dy=0;
        setPos(x()+dx,y()+dy);
        //left=true;
         mode=false;
      //  i=-1;
        //j=0;
    }
    else
    {
        mode=true;
    }*/
        if(goLeft(x(),y(),0,5)){
            setPos(x()-DD,y());
            mode = false;
        }
        else
            mode = true;

    if(mode)
        side=qrand()%4;
    break;

    case 3:
    /*if(map[(int)(y()/20)-1][(int)((x()/20))]!='W')
    {
        dx=0;dy=-DD;
        setPos(x()+dx,y()+dy);
        //up=true;
         mode=false;
    //   i=0;
      // j=-1;
    }
    else
    {
        mode=true;
    }*/
        if(goUp(x(),y(),0,5)){
            setPos(x(),y()-DD);
            mode = false;
        }
        else
            mode = true;
    if(mode)
        side=qrand()%4;
    break;
    }

}
