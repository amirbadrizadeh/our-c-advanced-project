#include "dot.h"
int dot::located=0;

dot::dot()
{
    myscore = 10;
    image=new QPixmap(":/img/resourses/image/dot.png");

    int counter=-1;
    bool is_broken=false;
    for(int i=0; i<31; ++i){
        for(int j=0; j<28; ++j){

            if(map[i][j] == '*'){
                ++counter;
            }

            if(located == counter){
                setPos(j*20+7,i*20+7);
                ++located;
                is_broken=true;
                break;
            }
        }
        if(is_broken)
            break;
    }
}
QRectF dot::boundingRect()const
{
    return QRectF(-1,-1,image->width(),image->height());
}
void dot::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(0,0,image->width(),image->height(),*image);
}
