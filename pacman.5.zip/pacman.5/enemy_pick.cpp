#include "enemy_pick.h"
#include <QList>
#include <QGraphicsScene>
#include "pacman.h"
#define DDD 20

enemy_pick::enemy_pick()
{
    image[0]=new QPixmap(":/img/resourses/image/pink.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");
    setPos(20,20);
    is_static=true;
}
QRectF enemy_pick::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_pick::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[0]->width(),image[0]->height(),(*image[0]));
}
void enemy_pick::advance(int)
{
    QList<QGraphicsItem*> list_pacman=scene()->items();
    int i,n;
    for(i=0,n=list_pacman.size(); i<n; ++i){
        if(typeid(*(list_pacman[i]))==typeid(pacman)){

            break;
        }
    }
    int dx,dy;
    if(x()<=list_pacman[i]->x()+55 && y()<=list_pacman[i]->y()+55){
        if( map[(int)(y()/20)][(int)((x()/20)+1)]!='W'){
            dx=DDD;dy=0;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }
        if(map[(int)(y()/20)+1][(int)((x()/20))]!='W'){
            dx=0;dy=DDD;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }

        enemy::advance(0);
    }

    else if(x()<=list_pacman[i]->x()+55 && y()>=list_pacman[i]->y()+55){
        if( map[(int)(y()/20)][(int)((x()/20)+1)]!='W'){
            dx=DDD;dy=0;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }
        if(map[(int)(y()/20)-1][(int)((x()/20))]!='W'){
            dx=0;dy=-DDD;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }
        enemy::advance(0);
    }

    else if(x()>=list_pacman[i]->x()+55 && y()<=list_pacman[i]->y()+55){
        if( map[(int)(y()/20)][(int)((x()/20)-1)]!='W'){
            dx=-DDD;dy=0;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }
        if(map[(int)(y()/20)+1][(int)((x()/20))]!='W'){
            dx=0;dy=DDD;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }
        enemy::advance(0);
    }

    else if(x()>=list_pacman[i]->x()+55 && y()>=list_pacman[i]->y()+55){
        if( map[(int)(y()/20)][(int)((x()/20)-1)]!='W'){
            dx=-DDD;dy=0;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }
        if(map[(int)(y()/20)-1][(int)((x()/20))]!='W'){
            dx=0;dy=-DDD;
            setPos(x()+dx,y()+dy);
            is_static=false;
            //enemy::advance(0);
        }
        enemy::advance(0);
    }

    else if(is_static){
        ;//enemy::advance(0);
    }
    enemy::advance(0);
    //setPos(x()+dx, y()+dy);
    is_static=true;
}
