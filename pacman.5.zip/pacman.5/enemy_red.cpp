#include "enemy_red.h"

enemy_red::enemy_red()
{
    image[0]=new QPixmap (":/img/resourses/image/red.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");

    for(int i=0;i<31;i++)
        for(int j=0;j<28;j++)
        {
            if (map[i][j]=='W')
                boolean_array[i][j]=true;
            else
                boolean_array[i][j]=false;
        }
    for(int i=0;i<31;i++)
        for(int j=0;j<28;j++)
    lable_array[i][j]=0;
    setPos(20,20);
}
QRectF enemy_red::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_red::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[0]->width(),image[0]->height(),(*image[0]));
}
void enemy_red::advance(int)
{
    struct position{
        int x;
        int y;
    };
   position queue[100];
    bool cond=true;
    int i=0,j=0;
    queue[0].x=(int)(y()/20);
    queue[0].y=(int)(x()/20)+1;
   // map[(int)(y()/20)][(int)((x()/20)+1)
    while (!cond) {
        i++;
        if(boolean_array[queue[j].x][queue[j].y]==0&&lable_array[queue[j].x][queue[j].y]==0){
        lable_array[(int)(y()/20)][(int)((x()/20)+1)]=i;
        queue[j].x= (int)(y()/20);
        queue[j].y= (int)((x()/20));
        j++;
    }

     if(boolean_array[queue[j].x][queue[j].y]==0&&lable_array[queue[j].x][queue[j].y]==0){
        lable_array[(int)(y()/20)][(int)((x()/20)-1)]=i;
        queue[j].x= (int)(y()/20);
        queue[j].y= (int)((x()/20)-1);
        j++;
    }
     if(boolean_array[queue[j].x][queue[j].y]==0&&lable_array[queue[j].x][queue[j].y]==0){
        lable_array[(int)(y()/20)+1][(int)((x()/20))]=i;
        queue[j].x= (int)((y()/20)+1);
        queue[j].y= (int)((x()/20));
        j++;
    }
     if(boolean_array[queue[j].x][queue[j].y]==0&&lable_array[queue[j].x][queue[j].y]==0){
        lable_array[(int)(y()/20)-1][(int)((x()/20))]=i;
        queue[j].x= (int)((y()/20)-1);
        queue[j].y= (int)((x()/20));
        j++;
    }



    }
}
