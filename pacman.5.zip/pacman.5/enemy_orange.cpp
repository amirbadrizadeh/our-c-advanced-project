#include "enemy_orange.h"


enemy_orange::enemy_orange()
{
    image[0] = new QPixmap(":/img/resourses/image/orange.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");

    setPos(20,20);
    side=0;



}
QRectF enemy_orange::boundingRect() const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_orange::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[0]->width(),image[0]->height(),(*image[0]));
}

void enemy_orange::advance(int)
{

    enemy::advance(0);

}
