#include "pacman.h"
#include <math.h>
#include <QList>
#include <QGraphicsScene>
#include "dot.h"
#include "coin.h"
#include "enemy.h"
#include "enemy_orange.h"
#define DISTANCE 5

pacman::pacman()
{
    life = 3;
    eaten=0;
    image[0] = new QPixmap(":/img/resourses/image/0.png");
    image[1] = new QPixmap(":/img/resourses/image/1.png");
    image[2] = new QPixmap(":/img/resourses/image/2.png");
    image[3] = new QPixmap(":/img/resourses/image/3.png");
    image[4] = new QPixmap(":/img/resourses/image/4.png");
    image[5] = new QPixmap(":/img/resourses/image/5.png");

    what_showing = 0;


    setScale(20/130.0);
    //setScale(2);
    setTransformOriginPoint(image[what_showing]->width()/2, image[what_showing]->height()/2);


    //setPos(465,225);
    setPos(13*20-55,23*20-55);


}
QRectF pacman::boundingRect()const
{
    int adjust=1;
    return QRectF(0-adjust, 0-adjust, image[what_showing]->width()+adjust
                  , image[what_showing]->height()+adjust);
}
QPainterPath pacman::shape()const
{
    QPainterPath path;
    path.addRect(0,0,image[what_showing]->width(),image[what_showing]->height());
    return path;
}
void pacman::paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    painter->drawPixmap(0,0,image[what_showing]->width(),image[what_showing]->height(),(*image[what_showing]));
   // painter->drawText(0,0,20,20,1,QString::number(x()));
}

void pacman::advance(int)
{


}

void pacman::keyPressEvent(QKeyEvent *event)
{
    if(eaten==dot::num)
        return;

    QList<QGraphicsItem*> list = collidingItems();
    for(int i=0,n=list.size(); i<n; ++i){
        if(typeid(*(list[i]))==typeid(dot)){
            scene()->removeItem(list[i]);
            ++eaten;
            //return;
        }
        if(typeid(*(list[i]))==typeid(coin)){
            scene()->removeItem(list[i]);
            /*QList<QGraphicsItem*> list_enemy = scene()->items();
            int j,m;
            for(j=0,m=list_enemy.size(); j<m; ++j){
                if(typeid(*(list_enemy[i]))==typeid(enemy_orange)){
                    list[i]->setScale(1);
                }
            }*/

            return;
        }
    }

    if(++what_showing==6)
        what_showing=0;

    switch(event->key()){

    case Qt::Key_Right:
        if(x()>465){
            setPos(x()+DISTANCE, y());
            if(x()>500)
                setPos(-70,y());
            return;
        }
        /*if(map[(int)(y()+55)/20][(int)((x()+75)/20)] == 'W' )
            return;
        else if(map[(int)::floor(((y()+55)/20)-1)][(int)::floor((x()+75)/20)] == 'W' && ::floor((y()+55)/20)!=(y()+55)/20)
            return;
        else
            setPos(x()+DISTANCE, y());*/
        if(goRight(x(),y(),55))
            setPos(x()+DISTANCE, y());
        else return;

        setRotation(0);
        break;

    case Qt::Key_Left:
        if(x()<-55){
            setPos(x()-DISTANCE, y());
            if(x()<-70)
                setPos(500,y());
            return;
        }
        /*if(map[(int)(y()+55)/20][(int)((x()+50)/20)] == 'W' )
            return;
        else if(map[(int)(((y()+55)/20)-1)][(int)(((x()+50)/20))] == 'W' && ::floor((y()+55)/20)!=(y()+55)/20 )
            return;
        else
            setPos(x()-DISTANCE, y());*/
        if(goLeft(x(),y(),55,5))
            setPos(x()-DISTANCE,y());
        else
            return;

        setRotation(180);
        break;

    case Qt::Key_Up:
        /*if(map[(int)((y()+70)/20-1)][(int)(x()+55)/20] == 'W')
            return;
        else if(map[(int)((y()+70)/20-1)][(int)((x()+55)/20-1)] == 'W' && ::floor((x()+55)/20) != (x()+55)/20)
            return;
        else
            setPos(x(), y()-DISTANCE);*/
        if(goUp(x(),y(),55,5))
            setPos(x(), y()-DISTANCE);
        else return;

        setRotation(270);

        break;

    case Qt::Key_Down:
        /*if(map[(int)((y()+55)/20+1)][(int)(x()+55)/20] == 'W')
            return;
        else if(map[(int)((y()+55)/20+1)][(int)((x()+55)/20-1)] == 'W' && ::floor((x()+55)/20) != (x()+55)/20)
            return;
        else
            setPos(x(), y()+DISTANCE);*/

        if(goDown(x(),y(),55))
            setPos(x(),y()+DISTANCE);
        else
            return;

        setRotation(90);

        break;

    default:
        QGraphicsItem::keyPressEvent(event);
    }
}

pacman::~pacman()
{
    for(int i = 0; i<6; ++i)
        delete image[i];
}
