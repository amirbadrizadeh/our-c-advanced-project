#ifndef MOVING_H
#define MOVING_H
#include "mainobject.h"
#include "math.h"

class moving:public mainObject
{
public:
    moving();
    bool goRight(qreal x,qreal y,qreal originPoint)
    {
        if(map[(int)(y+originPoint)/20][(int)((x+20+originPoint)/20)] == 'W' )
            return false;
        else if(map[(int)::floor(((y+originPoint)/20)-1)][(int)::floor((x+20+originPoint)/20)] == 'W' && ::floor((y+originPoint)/20)!=(y+originPoint)/20)
            return false;
        else
            return true;
    }
    bool goLeft(qreal x,qreal y,qreal originPoint,qreal mistake)
    {
        if(map[(int)(y+originPoint)/20][(int)((x+originPoint-mistake)/20)] == 'W' )
            return false;
        else if(map[(int)(((y+originPoint)/20)-1)][(int)(((x+originPoint-mistake)/20))] == 'W' && ::floor((y+originPoint)/20)!=(y+originPoint)/20 )
            return false;
        else
            return true;
    }

    bool goUp(qreal x,qreal y,qreal originPoint,qreal mistake)
    {
        if(map[(int)((y+20+originPoint-mistake)/20-1)][(int)(x+originPoint)/20] == 'W')
            return false;
        else if(map[(int)((y+20+originPoint-mistake)/20-1)][(int)((x+originPoint)/20-1)] == 'W' && ::floor((x+originPoint)/20) != (x+originPoint)/20)
            return false;
        else
            return true;
    }
    bool goDown(qreal x,qreal y,qreal originPoint)
    {
        if(map[(int)((y+originPoint)/20+1)][(int)(x+originPoint)/20] == 'W')
            return false;
        else if(map[(int)((y+originPoint)/20+1)][(int)((x+originPoint)/20-1)] == 'W' && ::floor((x+originPoint)/20) != (x+originPoint)/20)
            return false;
        else
            return true;
    }
};

#endif // MOVING_H
