#include "mainobject.h"
#include <QByteArray>

mainObject::mainObject()
{
    // Open the map file and initialize a QTextStream object.
    QFile mapFile(":/file/resourses/file/map.txt");
    if (!mapFile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        // TODO: implement notifying the user of missing data.
        qDebug("Error: map file not found.");
        return;
    }

    QTextStream textStream(&mapFile);

    // Read the data until the end of file, omitting ASCII control characters.
    char current;
    int i = 0,j = 0;
    while (!textStream.atEnd())
    {
        textStream >> current;
        map[i][j] = current;

        if(++j == 28){
            ++i;
            j = 0;
            textStream >> current;//for read '\n'
        }
        if(i==31)
            break;
    }

    mapFile.close();
}
