#ifndef SOUR_CHERRY_H
#define SOUR_CHERRY_H
#include "eat_able.h"

class sour_cherry:public eat_able
{
public:
    sour_cherry();

private:
    int myscore;
};

#endif // SOUR_CHERRY_H
