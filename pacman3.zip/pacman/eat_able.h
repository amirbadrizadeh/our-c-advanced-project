#ifndef EAT_ABLE_H
#define EAT_ABLE_H
#include "mainobject.h"

class eat_able:public mainObject
{
public:
    eat_able();
};

#endif // EAT_ABLE_H
