#include "wall.h"

wall::wall()
{
}
