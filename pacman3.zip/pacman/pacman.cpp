#include "pacman.h"

pacman::pacman()
{
    life = 3;
    image[0] = new QPixmap(":/img/resourses/image/0.png");
    image[1] = new QPixmap(":/img/resourses/image/1.png");
    image[2] = new QPixmap(":/img/resourses/image/2.png");
    image[3] = new QPixmap(":/img/resourses/image/3.png");
    image[4] = new QPixmap(":/img/resourses/image/4.png");
    image[5] = new QPixmap(":/img/resourses/image/5.png");

    what_showing = 0;
}
QRectF pacman::boundingRect()const
{
    return QRectF(0-1, 0-1, image[what_showing]->width()+1, image[what_showing]->height()+1);
}
QPainterPath pacman::shape()const
{
    QPainterPath path;
    path.addRect(0,0,image[what_showing]->width(),image[what_showing]->height());
    return path;
}
void pacman::paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    painter->drawPixmap(0,0,image[what_showing]->width(),
                        image[what_showing]->height(),(*image[what_showing]));
}

void pacman::advance(int)
{
    setPos(x() + 1 ,y());
    if(++what_showing == 6)
        what_showing = 0;
}

pacman::~pacman()
{
    for(int i = 0; i<6; ++i)
        delete image[i];
}
