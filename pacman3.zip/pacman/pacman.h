#ifndef PACMAN_H
#define PACMAN_H
#include "moving.h"
#include <QPixmap>
#include <QPainterPath>

class pacman:public moving
{
public:
    pacman();
    ~pacman();

    QRectF boundingRect()const;
    QPainterPath shape() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*);

protected:
    void advance(int);

private:
    int life;
    QPixmap *image[6];
    int what_showing;
};

#endif // PACMAN_H
