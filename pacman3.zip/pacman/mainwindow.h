#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QTimer>
#include "pacman.h"
#include "coin.h"
#include "progress.h"
#include "wall.h"
#include "dot.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    QGraphicsView *view;
    QGraphicsScene *scene;
    QTimer *timer;

    pacman *pac;


};

#endif // MAINWINDOW_H
