#include "mainwindow.h"
#include "mainobject.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("Pac Man");
    setFixedSize(570,650);

    view = new QGraphicsView(this);
    view->setFixedSize(570,650);

    scene = new QGraphicsScene(0,0,570-2,650-2);
    view->setScene(scene);

    // Add wall

    // Add dot

    // Add coin

    // Add pacman
    pac = new pacman;
    pac->setScale(20/130.0);
    scene->addItem(pac);

    // Add enemy

    // Add progress

    timer = new QTimer;
    connect(timer,SIGNAL(timeout()),scene,SLOT(advance()));
    timer->start(100);
}

MainWindow::~MainWindow()
{
    delete view;
    delete scene;
    delete timer;
    //delete pac;
}
