#ifndef ENEMY_H
#define ENEMY_H
#include "moving.h"
#include <QPixmap>

class enemy:public moving
{
public:
    enemy();

    void setMode();

private:
    bool mode;

};

#endif // ENEMY_H
