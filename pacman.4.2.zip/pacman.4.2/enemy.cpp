#include "enemy.h"

enemy::enemy()
{
    mode = true;//oridinary
}
