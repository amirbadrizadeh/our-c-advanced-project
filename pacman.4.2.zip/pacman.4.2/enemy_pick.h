#ifndef ENEMY_PICK_H
#define ENEMY_PICK_H
#include "enemy.h"

class enemy_pick:public enemy
{
public:
    enemy_pick();
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
private:
    QPixmap *image[2];
};

#endif // ENEMY_PICK_H
