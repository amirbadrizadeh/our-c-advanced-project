#include "enemy_orange.h"
#define DD 20

enemy_orange::enemy_orange()
{
    image[0] = new QPixmap(":/img/resourses/image/orange.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");

    setPos(20,20);


}
QRectF enemy_orange::boundingRect() const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_orange::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(0,0,image[0]->width(),image[0]->height(),(*image[0]));
}

void enemy_orange::advance(int)
{
    int side,i=0,j=1;
    if(map[(int)(y()/20)+i][(int)((x()/20)+j)]=='W'){
        side=qrand()%4;}
    switch(side){
    case 0:

    if( map[(int)(y()/20)][(int)((x()/20)+1)]!='W'){
        dx=DD;dy=0;
        setPos(x()+dx,y()+dy);
        i=1;
        j=0;

    }
    break;

    case 1:
    if(map[(int)(y()/20)+1][(int)(x()/20)]!='W'){
        dx=0;dy=DD;
        setPos(x()+dx,y()+dy);
        i=0;
        j=1;

    }
    break;

    case 2:
    if(map[(int)(y()/20)-1][(int)(x()/20)]!='W'){
        dx=0;dy=-DD;
        setPos(x()+dx,y()+dy);
        i=0;
        j=-1;
    }
    break;

    case 3:
    if(map[(int)(y()/20)][(int)(x()/20-1)]!='W'){
        dx=-DD;dy=0;
        setPos(x()+dx,y()+dy);
       i=-1;
       j=0;
    }
    break;
    }





    //setPos(x()+dx,y()+dy);
}
