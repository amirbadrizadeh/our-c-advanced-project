#include "enemy_blue.h"

enemy_blue::enemy_blue()
{
    image[0]=new QPixmap(":/img/resourses/image/blue.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");
    setPos(13*20,14*20);
    state=0;
    timer=0;
}
QRectF enemy_blue::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}

void enemy_blue::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[state]->width(),image[state]->height(),(*image[state]));
}
void enemy_blue::advance(int)
{
    if(x()>12*20 && x()<15*20 && y()>11*20 && y()<15*20){
        setPos(x(),y()-5);
        return;
    }
    else{
        if(state==1){
            timer+=TIMER_ADD;
        }
        if(timer>=TIMER_END)
            state=0;
    }

    pacman *pac;
    QList<QGraphicsItem*> list_pacman = scene()->items();
    for(int i=0,n=list_pacman.size();i<n;++i){
        pac=dynamic_cast<pacman*>(list_pacman[i]);
        if(pac)
            break;
    }


    moveRandom(DRANDOM);

    if(x()<=pac->x()+55 && y()<=pac->y()+55){
        if(goRight(x(),y(),0,0)){
            setPos(x()+DDD,y());

        }
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DDD);

        }
    }
    else if(x()>=pac->x()+55 && y()<=pac->y()+55){
        if(goLeft(x(),y(),0,DDD)){
            setPos(x()-DDD,y());

        }
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DDD);

        }

    }



}

int enemy_blue::getState()
{
    return state;
}
void enemy_blue::setStrong()
{
    state=0;
}
void enemy_blue::setWeak()
{
    state=1;
    timer=0;
}

enemy_blue::~enemy_blue()
{
    delete image[0];
    delete image[1];
}
