#ifndef ENEMY_H
#define ENEMY_H
#include "moving.h"
#include <QPixmap>
#include <QList>
#include <QGraphicsScene>
#include "pacman.h"
#define TIMER_ADD 100
#define TIMER_END 10000
#define DRANDOM 4
#define DDD 2

class enemy:public moving
{
public:
    enemy();

    virtual int getState()=0;
    virtual void setStrong()=0;
    virtual void setWeak()=0;

protected:
    void moveRandom(qreal);

private:
    bool mode;
    int side;

};


#endif // ENEMY_H
