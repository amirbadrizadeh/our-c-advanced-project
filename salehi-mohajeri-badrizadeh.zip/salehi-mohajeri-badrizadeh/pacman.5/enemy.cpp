#include "enemy.h"

enemy::enemy()
{
    mode = true;
    side=0;
}
void enemy::moveRandom(qreal speed)
{
    switch(side){
    case 0://Right
        if(goRight(x(),y(),0,0)){
            setPos(x()+speed, y());
            mode = false;
        }
        else
            mode=true;
        if(mode)
            side=qrand()%4;
        break;

    case 1://Down
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+speed);
            mode=false;
        }
        else
            mode = true;
        if(mode)
            side=qrand()%4;
        break;

    case 2://Left
        if(goLeft(x(),y(),0,speed)){
            setPos(x()-speed,y());
            mode = false;
        }
        else
            mode = true;

        if(mode)
            side=qrand()%4;
        break;

    case 3://Up
        if(goUp(x(),y(),0,speed)){
            setPos(x(),y()-speed);
            mode = false;
        }
        else
            mode = true;
        if(mode)
             side=qrand()%4;
        break;
    }
}
