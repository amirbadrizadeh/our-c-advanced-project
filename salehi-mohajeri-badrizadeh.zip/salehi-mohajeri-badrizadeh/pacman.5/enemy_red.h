#ifndef ENEMY_RED_H
#define ENEMY_RED_H
#include "enemy.h"

class enemy_red:public enemy
{
public:
    enemy_red();
    ~enemy_red();

    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    int getState();
    void setStrong();
    void setWeak();

protected:
    void advance(int);
private:

    QPixmap *image[2];
    int state;
    int timer;
};

#endif // ENEMY_RED_H
