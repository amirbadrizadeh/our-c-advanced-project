#ifndef COIN_H
#define COIN_H
#include "eat_able.h"

class coin:public eat_able
{
     static int located;
public:
    static const int num=4;

    coin();
    ~coin();
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    QPixmap *image;

};

#endif // COIN_H
