#ifndef DOT_H
#define DOT_H
#include "eat_able.h"

class dot:public eat_able
{
    static int located;
public:
    static const int num=240;
    dot();
    ~dot();
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);


private:
    QPixmap *image;
};

#endif // DOT_H
