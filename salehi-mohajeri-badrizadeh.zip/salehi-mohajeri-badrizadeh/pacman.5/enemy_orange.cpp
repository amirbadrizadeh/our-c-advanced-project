#include "enemy_orange.h"


enemy_orange::enemy_orange()
{
    image[0] = new QPixmap(":/img/resourses/image/orange.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");

    setPos(13*20,14*20);
    state=0;
    timer=0;

}
QRectF enemy_orange::boundingRect() const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_orange::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[state]->width(),image[state]->height(),(*image[state]));
}

void enemy_orange::advance(int)
{
    if(x()>12*20 && x()<15*20 && y()>11*20 && y()<15*20){
        setPos(x(),y()-5);
        return;
    }
    else{
        if(state==1){
            timer+=TIMER_ADD;
        }
        if(timer>=TIMER_END){
            state=0;
            timer=0;
        }
    }
    moveRandom(5);

}
int enemy_orange::getState()
{
    return state;
}
void enemy_orange::setStrong()
{
    state=0;
}
void enemy_orange::setWeak()
{
    state=1;
    timer=0;
}

enemy_orange::~enemy_orange()
{
    delete image[0];
    delete image[1];
}
