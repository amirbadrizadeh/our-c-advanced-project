#ifndef MOVING_H
#define MOVING_H
#include "mainobject.h"
#include "math.h"

class moving:public mainObject
{
public:
    moving();
    bool goRight(qreal x,qreal y,qreal originPoint,qreal mistake);


    bool goLeft(qreal x,qreal y,qreal originPoint,qreal mistake);


    bool goUp(qreal x,qreal y,qreal originPoint,qreal mistake);

    bool goDown(qreal x,qreal y,qreal originPoint,qreal mistake);

};

#endif // MOVING_H
