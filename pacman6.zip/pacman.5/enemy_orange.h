#ifndef ENEMY_ORANGE_H
#define ENEMY_ORANGE_H
#include "enemy.h"

class enemy_orange:public enemy
{
public:
     enemy_orange();
     ~enemy_orange();

     QRectF boundingRect()const;
     void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

     int getState()
     {
         return state;
     }

     void setStrong()
     {
         state=0;
     }
     void setWeak()
     {
         state=1;
         timer=0;
     }
    void advance(int);
private:
         QPixmap *image[2];
        int state;
        int timer;
       // bool mode;

};

#endif // ENEMY_ORANGE_H
