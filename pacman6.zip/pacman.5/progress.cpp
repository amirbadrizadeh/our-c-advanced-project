#include "progress.h"
#include <QPainter>
#include <QString>

progress::progress()
{

    setPos(0,620);
    score=0;

    setPlainText(QString("score:")+QString::number(score));
    setDefaultTextColor(Qt::darkMagenta);
    setFont(QFont("Armor Piercing",12));
}


void progress::setScore(int s)
{
    score+=s;
    setPlainText(QString("score:")+QString::number(score));
}
void progress::loose(){
    setPos(14*20-130,15*20-60);
    setDefaultTextColor(Qt::red);
    setFont(QFont("broadway",12));
    setPlainText("GAME OVER");

}
void progress::win() {
    setPos(14*20-170,15*20-80);
    setDefaultTextColor(Qt::cyan);
    setFont(QFont("Big Bloke BB",27));
    setPlainText("YOU WIN");
}
