#ifndef ENEMY_H
#define ENEMY_H
#include "moving.h"
#include <QPixmap>

class enemy:public moving
{
public:
    enemy();
    virtual int getState()=0;

    virtual void setStrong()=0;
    virtual void setWeak()=0;



protected:
    void moveRandom(qreal);

private:
    bool mode;
    int state;

    int side;

};


#endif // ENEMY_H
