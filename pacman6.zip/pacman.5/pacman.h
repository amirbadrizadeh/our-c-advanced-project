#ifndef PACMAN_H
#define PACMAN_H
#include "moving.h"
#include <QPixmap>
#include <QPainterPath>
#include <QKeyEvent>
#include <QTimer>
#include <QObject>
#include "progress.h"

class pacman:public moving
{
public:
    pacman();
    ~pacman();

    QRectF boundingRect()const;
    QPainterPath shape() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*);

protected:
    void advance(int phase);
    void keyPressEvent(QKeyEvent *event);

private:
    int life;
    QPixmap *image[6];
    int what_showing;

    int eaten;
    progress *prog;

};

#endif // PACMAN_H
