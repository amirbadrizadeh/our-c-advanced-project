#ifndef PROGRESS_H
#define PROGRESS_H
#include <QGraphicsTextItem>
#include <QFont>

class progress:public QGraphicsTextItem
{
public:
    progress();

    void setScore(int s);

    void loose();

    void win() ;

private:
    int score;

};

#endif // PROGRESS_H
