#include "enemy_blue.h"

enemy_blue::enemy_blue()
{
    image[0]=new QPixmap(":/img/resourses/image/blue.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");
    setPos(13*20,14*20);
    state=0;
    timer=0;
}
QRectF enemy_blue::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}

void enemy_blue::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[state]->width(),image[state]->height(),(*image[state]));
}
void enemy_blue::advance(int)
{
    if(x()>12*20 && x()<15*20 && y()>11*20 && y()<15*20){
        setPos(x(),y()-5);
    }
    else{
        if(state==1){
            timer+=100;
        }
        if(timer>=10000)
            state=0;
        moveRandom(5);

    }

}

enemy_blue::~enemy_blue()
{
    delete image[0];
    delete image[1];
}
