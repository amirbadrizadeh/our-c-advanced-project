#include "wall.h"

int wall::located = 0;

wall::wall()
{
    image = new QPixmap(":/img/resourses/image/wall.png");

    int counter=-1;
    bool is_broken=false;
    for(int i=0; i<31; ++i){
        for(int j=0; j<28; ++j){

            if(map[i][j] == 'W'){
                ++counter;
            }

            if(located == counter){
                setPos(j*20,i*20);
                ++located;
                is_broken=true;
                break;
            }
        }
        if(is_broken)
            break;
    }
}

QRectF wall::boundingRect() const
{
    return QRectF(0, 0, image->width(), image->height());
}
void wall::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0, 0, image->width(), image->height(), *image);
}
wall::~wall()
{
    delete image;
}
