#ifndef PROGRESS_H
#define PROGRESS_H
#include <QGraphicsItem>

class progress:public QGraphicsItem
{
public:
    progress();
};

#endif // PROGRESS_H
