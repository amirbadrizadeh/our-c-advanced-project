#include "progress.h"

progress::progress()
{
}
