#include "enemy.h"
#define DD 20

enemy::enemy()
{
    mode = true;//oridinary
    side=0;
}
void enemy::advance(int){
    switch(side){
    case 0:

    if( map[(int)(y()/20)][(int)((x()/20)+1)]!='W'){
        dx=DD;dy=0;
        setPos(x()+dx,y()+dy);
        mode=false;
        //i=0;
        //j=1;
    }
    else
    {
        mode=true;
    }
    if(mode)
        side=qrand()%4;
    break;

    case 1:
    if(map[(int)(y()/20)+1][(int)(x()/20)]!='W')
    {
        dx=0;dy=DD;
        setPos(x()+dx,y()+dy);
    //    down=true;
         mode=false;
      //  i=1;
        //j=0;
    }
    else
    {
        mode=true;
    }
    if(mode)
        side=qrand()%4;
    break;

    case 2:
    if(map[(int)(y()/20)][(int)(x()/20)-1]!='W')
    {
        dx=-DD;dy=0;
        setPos(x()+dx,y()+dy);
        //left=true;
         mode=false;
      //  i=-1;
        //j=0;
    }
    else
    {
        mode=true;
    }
    if(mode)
        side=qrand()%4;
    break;

    case 3:
    if(map[(int)(y()/20)-1][(int)((x()/20))]!='W')
    {
        dx=0;dy=-DD;
        setPos(x()+dx,y()+dy);
        //up=true;
         mode=false;
    //   i=0;
      // j=-1;
    }
    else
    {
        mode=true;
    }
    if(mode)
        side=qrand()%4;
    break;
    }

}
