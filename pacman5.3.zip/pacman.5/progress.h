#ifndef PROGRESS_H
#define PROGRESS_H
#include <QGraphicsItem>

class progress:public QGraphicsItem
{
public:
    progress();
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*);

private:
    int score;
};

#endif // PROGRESS_H
