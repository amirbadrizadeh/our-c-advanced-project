#ifndef ENEMY_PICK_H
#define ENEMY_PICK_H
#include "enemy.h"

class enemy_pick:public enemy
{
public:
    enemy_pick();
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    int getState()
    {
        return state;
    }
    void setStrong()
    {
        state=0;
    }
    void setWeak()
    {
        state=1;
        timer=0;
    }

protected:
    void advance(int);
private:
    QPixmap *image[2];
    bool is_static;
    int state;
    int timer;

};

#endif // ENEMY_PICK_H
