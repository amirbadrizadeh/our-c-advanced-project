#ifndef ENEMY_BLUE_H
#define ENEMY_BLUE_H
#include "enemy.h"

class enemy_blue:public enemy
{
public:
    enemy_blue();
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    int getState()
    {
        return state;
    }
    void setStrong()
    {
        state=0;
    }
    void setWeak()
    {
        state=1;
        timer=0;
    }

protected:
    void advance(int);


private:
    QPixmap *image[2];
    int state;
    int timer;
};

#endif // ENEMY_BLUE_H
