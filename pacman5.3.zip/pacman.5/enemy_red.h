#ifndef ENEMY_RED_H
#define ENEMY_RED_H
#include "enemy.h"

class enemy_red:public enemy
{
public:
    enemy_red();
    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    int getState()
    {
        return state;
    }
    void setStrong()
    {
        state=0;
    }
    void setWeak()
    {
        state=1;
        timer=0;
    }

    void advance(int);
private:
    QPixmap *image[2];
    int state;
    int timer;
    bool boolean_array[31][28];
    int lable_array[31][28];
 //   protected:
   // void advance(int);
};

#endif // ENEMY_RED_H
