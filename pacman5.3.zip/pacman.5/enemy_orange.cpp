#include "enemy_orange.h"


enemy_orange::enemy_orange()
{
    image[0] = new QPixmap(":/img/resourses/image/orange.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");

    setPos(13*20,14*20);
    state=0;
    timer=0;

}
QRectF enemy_orange::boundingRect() const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_orange::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[state]->width(),image[state]->height(),(*image[state]));
}

void enemy_orange::advance(int)
{
    if(x()>12*20 && x()<15*20 && y()>11*20 && y()<15*20){
        setPos(x(),y()-5);
    }
    else{
        if(state==1){
            timer+=100;
        }
        if(timer>=10000){
            state=0;
            timer=0;
        }
        /*if(state==0){
            enemy::moveRandom(5);
        }
        else{
            enemy::moveRandom(5);
        }*/
        moveRandom(5);

    }

}
