#include "coin.h"

int coin::located=0;
coin::coin()
{
    myscore = 50;
    image=new QPixmap(":/img/resourses/image/coin.png");

    int counter=-1;
    bool is_broken=false;
    for(int i=0; i<31; ++i){
        for(int j=0; j<28; ++j){

            if(map[i][j] == 'O'){
                ++counter;
            }

            if(located == counter){
                setPos(j*20,i*20);
                ++located;
                is_broken=true;
                break;
            }
        }
        if(is_broken)
            break;
    }
}

QRectF coin::boundingRect()const
{
    return QRectF(-1,-1,image->width(),image->height());
}
void coin::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image->width(),image->height(),*image);
}
