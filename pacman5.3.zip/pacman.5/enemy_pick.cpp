#include "enemy_pick.h"
#include <QList>
#include <QGraphicsScene>
#include "pacman.h"
#define DDD 2.5

enemy_pick::enemy_pick()
{
    image[0]=new QPixmap(":/img/resourses/image/pink.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");
    setPos(14*20,14*20);
    is_static=true;
    state=0;
    timer=0;
}
QRectF enemy_pick::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_pick::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[state]->width(),image[state]->height(),(*image[state]));
}
void enemy_pick::advance(int)
{


    /*if(x()<=list_pacman[i]->x()+55 && y()<=list_pacman[i]->y()+55){
        if(goRight(x(),y(),0,0)){
            setPos(x()+DDD,y());
            is_static=false;
        }
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DDD);
            is_static=false;
        }

        enemy::advance(1);
    }*/

    /*else if(x()<=list_pacman[i]->x()+55 && y()>=list_pacman[i]->y()+55){
        if(goRight(x(),y(),0,0)){
            setPos(x()+DDD,y());
            is_static=false;
        }
        if(goUp(x(),y(),0,5)){
            setPos(x(),y()-DDD);
            is_static=false;
        }
        enemy::advance(1);
    }*/

    /*else if(x()>=list_pacman[i]->x()+55 && y()<=list_pacman[i]->y()+55){
        if(goLeft(x(),y(),0,5)){
            setPos(x()-DDD,y());
            is_static=false;
        }
        if(goDown(x(),y(),0,0)){
            setPos(x(),y()+DDD);
            is_static=false;
        }
        enemy::advance(1);
    }*/

    /*else if(x()>=list_pacman[i]->x()+55 && y()>=list_pacman[i]->y()+55){
        if(goLeft(x(),y(),0,5)){
            setPos(x()-DDD,y());
            is_static=false;
        }
        if(goUp(x(),y(),0,5)){
            setPos(x(),y()-DDD);
            is_static=false;
        }
        enemy::advance(1);
    }*/
    if(x()>12*20 && x()<15*20 && y()>11*20 && y()<15*20){
        setPos(x(),y()-5);
    }
    else{
        if(state==1){
            timer+=100;
        }
        if(timer>=10000)
            state=0;
        /*if(state==0){
            enemy::moveRandom(5);
        }
        else{
            enemy::moveRandom(3);
        }*/
        enemy::moveRandom(5);

    }
}
