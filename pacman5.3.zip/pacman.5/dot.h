#ifndef DOT_H
#define DOT_H
#include "eat_able.h"

class dot:public eat_able
{
public:
    static const int num=240;
    static int located;
    dot();

    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);


private:
    int myscore;
    QPixmap *image;
};

#endif // DOT_H
