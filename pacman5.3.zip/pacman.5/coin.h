#ifndef COIN_H
#define COIN_H
#include "eat_able.h"

class coin:public eat_able
{
public:
    static const int num=4;
    static int located;
    coin();
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    QPixmap *image;
    int myscore;
};

#endif // COIN_H
