#include "progress.h"
#include <QPainter>

progress::progress()
{
    score=50;
}
QRectF progress::boundingRect()const
{
    return QRectF(0,0,60,60);
}
void progress::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawText(0,0,50,50,1,"SCORE:");
    painter->drawText(10,10,50,50,0,QString::number(score));
}
