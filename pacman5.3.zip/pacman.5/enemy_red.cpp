#include "enemy_red.h"

enemy_red::enemy_red()
{
    image[0]=new QPixmap (":/img/resourses/image/red.png");
    image[1]=new QPixmap(":/img/resourses/image/ghost.png");

    for(int i=0;i<31;i++)
        for(int j=0;j<28;j++)
        {
            if (map[i][j]=='W')
                boolean_array[i][j]=true;
            else
                boolean_array[i][j]=false;
        }
    for(int i=0;i<31;i++)
        for(int j=0;j<28;j++)
    lable_array[i][j]=0;
    setPos(14*20,14*20);
    state=0;
    timer=0;
}
QRectF enemy_red::boundingRect()const
{
    return QRectF(0-1,0-1,image[0]->width()+1,image[0]->height()+1);
}
void enemy_red::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->drawPixmap(0,0,image[state]->width(),image[state]->height(),(*image[state]));
}
void enemy_red::advance(int)
{
    if(x()>12*20 && x()<15*20 && y()>11*20 && y()<15*20){
        setPos(x(),y()-5);
    }
    else{
        if(state==1){
            timer+=100;
        }
        if(timer>=10000)
            state=0;
        enemy::moveRandom(5);

    }
}
